"use strict";
exports.id = 520;
exports.ids = [520];
exports.modules = {

/***/ 62787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MainFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97829);
/* harmony import */ var _constants_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43830);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function MainFooter() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Container */ .W2, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Row */ .X2, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 3,
                            md: 3,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "footerlogo",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_constants_svg__WEBPACK_IMPORTED_MODULE_1__/* .FooterLogo */ .wi, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: ' Trade your goods and services with others in your community with ease." '
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 2,
                            md: 2,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    children: "About"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "About Us "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Terms & Conditions "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Privacy Policy "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Blogs "
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 2,
                            md: 2,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    children: "Information"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Help Center "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Money Refund "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Shipping "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Contact us "
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 2,
                            md: 2,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    children: "For Users"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Login "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Register "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "Settings "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                                    children: "My Orders  "
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 2,
                            md: 2,
                            className: "footerAppLink",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    children: "Get app"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                    children: [
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_constants_svg__WEBPACK_IMPORTED_MODULE_1__/* .IconDownloadAppStore */ .JI, {})
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .NavLink */ .OL, {
                                    children: [
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_constants_svg__WEBPACK_IMPORTED_MODULE_1__/* .IconDownloadPlayStore */ .yM, {})
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "copyRight",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Container */ .W2, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Row */ .X2, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__/* .Col */ .JX, {
                            lg: 12,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "copy__content",
                                children: "\xa9 2023 MeeM Souk. "
                            })
                        })
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 32110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MainHeader)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/index.js
var cjs = __webpack_require__(97829);
// EXTERNAL MODULE: ./src/constants/svg.js
var svg = __webpack_require__(43830);
// EXTERNAL MODULE: ./node_modules/antd/lib/index.js
var lib = __webpack_require__(2318);
;// CONCATENATED MODULE: ./src/assets/images/avatar/avatar.png
/* harmony default export */ const avatar = ({"src":"/_next/static/media/avatar.1c316b62.png","height":35,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AfXp7wACFg0bCOHziuXf2j7Y4tUACBIUwTtMTXb04+bmAfT39SEB2u/AzsjGHvv06wD1+e8ADgkIAAAaIOI3Tk5AAfjY6rrp2uFFwtC9+jQnLQXf2MoA9vz5+/wABgb/IyG8AfLM6fr+7fEF0+HKAP707gDWybsA5/btACspNQDxFRv6AcWxyvkkBAsG5ObEAP3x6AC7u7gA8//0AB8fLgAdOEP7AdfAxrvw2+FE9/To+g8B9wW8wboA7fn0+yksOAYnQEu7Aejw7iHItLzA187XHgH59gD25tYAHSszABkpJeJJV1dAAdbT1AApLCsasK2xiu7n6D/n7ekAQTo9wjdCPnbj3N3ldRiMkgUUksUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/assets/images/map/map.png
/* harmony default export */ const map = ({"src":"/_next/static/media/map.9bbdda8b.png","height":154,"width":390,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAZklEQVR4nB3AvQ7BYBTG8f9zjvRLDHaLxWRyBW7bFTCwEqNBY5XQNm3enib96VHfxme6aG9HVqzJqgLJ+P++dE0TutfX+PQvdvmBwitSJAghc0Sg8/s0Dn2rTbfFs5KZGe4L8nIZE689IgxxS4iNAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./src/app/components/location/SearchLocation.js
/* __next_internal_client_entry_do_not_use__ default auto */ 






const data = [
    {
        location: "Terminal 3 - Dubai International Airport",
        airport: "Dubai - United Arab Emirates"
    },
    {
        location: "Terminal 3 - Dubai International Airport",
        airport: "Dubai - United Arab Emirates"
    },
    {
        location: "Terminal 3 - Dubai International Airport",
        airport: "Dubai - United Arab Emirates"
    }
];
function SearchLocation({ onCancel , initialstep  }) {
    const [step, setStep] = (0,react_.useState)(initialstep);
    const inputRef = (0,react_.useRef)(null);
    const [location, setLocation] = (0,react_.useState)("");
    const [selectedlocation, setSelectedlocation] = (0,react_.useState)(null);
    (0,react_.useEffect)(()=>{
        return ()=>{
            console.log("CLOSING");
        };
    }, []);
    (0,react_.useEffect)(()=>{
        if (location !== "") {
            console.log("LOcation", location);
        }
    }, [
        location
    ]);
    const selectLocation = (id)=>{
        let loc = data.find((el, idx)=>idx == id);
        setSelectedlocation(loc);
        setStep(1);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            step == 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "search__field",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs/* InputGroup */.BZ, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(svg/* SearchIcon */.W1, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Form.Control */.l0.Control, {
                                placeholder: "Search",
                                "aria-describedby": "basic-addon1",
                                ref: inputRef,
                                value: location,
                                onChange: (e)=>setLocation(e.target.value)
                            })
                        ]
                    }),
                    location.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "list__data",
                        children: data.map((el, idx)=>{
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "dropdoewn__locs",
                                onClick: ()=>selectLocation(idx),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(svg/* LocationBlueIcon */.Kr, {})
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "right",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "darkColor__para",
                                                children: el.location
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "lightColor__para",
                                                children: el.airport
                                            })
                                        ]
                                    })
                                ]
                            }, idx);
                        })
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(lib/* Divider */.iz, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "select__location",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(svg/* PointLocationIcon */.cY, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Use current location"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            step == 1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "maplocation__search",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "map__display"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "input margin_top_20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            placeholder: "Street Name",
                            className: "enter__input"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "margin_top_20",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "input__label",
                                children: [
                                    "Address ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "*"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "input ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    placeholder: "Street Name",
                                    value: selectedlocation.location,
                                    className: "enter__input"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "margin_top_23",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "blue__button",
                            onClick: ()=>onCancel(),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Done"
                            })
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/components/CustomModal.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


function CustomModal({ children , open , onCancel , heading  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Modal */.u_, {
        centered: true,
        open: open,
        closable: false,
        footer: null,
        className: "custom__modal",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "modal__header",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "heading",
                        children: heading
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "close__icon",
                        onClick: onCancel,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(svg/* ModalCloseIcon */.Su, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__body",
                children: children
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/components/MainHeader.js
/* __next_internal_client_entry_do_not_use__ default auto */ 









function MainHeader() {
    const [openlocation, setOpenlocation] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Container */.W2, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs/* Row */.X2, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Col */.JX, {
                            lg: 3,
                            md: 3,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "logoListing",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "main__Logo",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* NavLink */.OL, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(svg/* MainLogo */.zU, {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "item__ServiceLinking",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* NavLink */.OL, {
                                                        className: "active",
                                                        children: "Items"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* NavLink */.OL, {
                                                        children: "services "
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Col */.JX, {
                            lg: 5,
                            md: 5
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Col */.JX, {
                            lg: 4,
                            md: 4,
                            sm: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "right__listing",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(svg/* BellIcon */.Dk, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "avatar__image",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: avatar,
                                            alt: "avatar",
                                            className: "user__image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(svg/* HeartIcon */.h_, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "button__whitebg",
                                        style: {
                                            height: "35px"
                                        },
                                        children: " + Create New"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Space */.T, {
                                        size: 9,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(svg/* LocationIcon */._t, {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "country__name",
                                                children: "Pakistan"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                onClick: ()=>setOpenlocation((prev)=>!prev),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(svg/* DropIcon */.rs, {})
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CustomModal, {
                heading: "Custom Location",
                open: openlocation,
                onCancel: ()=>setOpenlocation(false),
                children: /*#__PURE__*/ jsx_runtime_.jsx(SearchLocation, {
                    onCancel: ()=>setOpenlocation(false),
                    initialstep: 0
                })
            })
        ]
    });
}


/***/ })

};
;